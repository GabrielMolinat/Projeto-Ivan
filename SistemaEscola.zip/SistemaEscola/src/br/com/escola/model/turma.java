package br.com.escola.model;

import java.util.ArrayList;
import java.util.List;

public class turma {
	private String nome;
	private List<aluno> alunos;
	
public turma(String nome) {
	this.nome = nome;
	this.alunos = new ArrayList<>();
}

public String getNome() {
	return nome;
}

public List<aluno> getAlunos(){
	return alunos;
}

public void adicionarAluno(aluno aluno) {
	alunos.add(aluno);
}
	
public String toString() {
	return nome + " (" + alunos.size() + " alunos)";
}

public void add(turma turma) {
	// TODO Auto-generated method stub
	
}
	
}
