package br.com.escola.service;

import java.util.ArrayList;
import java.util.List;

import br.com.escola.model.turma;

public class escolaservice {
	
	private List<turma> turmas = new ArrayList<>();
	
	public void adicionarTurmas(turma turma) {
		turma.add(turma);
	}
	
	public List<turma> listarTurmas() {
		return turmas;
	}
	
	public turma buscarTurma(int indice) {
		if(indice >= 0 && indice < turmas.size()) {
			return turmas.get(indice);
		}
		return null;
	}
	
	public boolean estaVazia() {
		return turmas.isEmpty();
	}
	
	
	
	
	
	
}